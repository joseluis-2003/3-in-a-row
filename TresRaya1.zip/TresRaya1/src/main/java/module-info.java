module com.example.tresraya1 {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.tresraya1 to javafx.fxml;
    exports com.example.tresraya1;
}